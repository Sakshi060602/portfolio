# JAVAFX LOGIN UI DESIGN WITH MYSQL DB INTERGRATION

Focus areas

- UI Design
- DB integration
- Insert - Retrieve

A simple sample to get you started.

![](https://github.com/k33ptoo/JavaFX-MySQL-Login/blob/master/img.png)

![](https://github.com/k33ptoo/JavaFX-MySQL-Login/blob/master/img2.png)