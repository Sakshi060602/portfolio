# Ticker iQ
[![Author](https://img.shields.io/badge/Author-ianramzy-brightgreen.svg)](https://ianramzy.com)
![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg) 
[![Donate](https://img.shields.io/badge/Donate-PayPal-brightgreen.svg)](https://paypal.me/ianramzy)
![GitHub repo size](https://img.shields.io/github/repo-size/ianramzy/ticker-iq.svg)
[![Repo Link](https://img.shields.io/badge/Repo-Link-black.svg)](https://github.com/ianramzy/ticker-iq)

📈 Stock screener and portfolio analyzer, providing key insights on financial reports, news articles and more!
For info on this project, installation instructions and screenshots see: 
# → https://ianramzy.com/project/ticker-iq.html
